from flask import Flask, render_template, request, redirect, url_for, session
from flask_socketio import SocketIO, join_room, leave_room, emit
from apscheduler.schedulers.background import BackgroundScheduler
import os, time

app = Flask(__name__)
app.secret_key = "feyzchat_secret"
socketio = SocketIO(app)

messages = []

def clear_old_messages():
    global messages
    now = time.time()
    messages = [msg for msg in messages if now - msg["timestamp"] < 5*24*60*60]

scheduler = BackgroundScheduler()
scheduler.add_job(func=clear_old_messages, trigger="interval", hours=24)
scheduler.start()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        username = request.form["username"]
        room = request.form["room"]
        session["username"] = username
        session["room"] = room
        return redirect(url_for("chat"))
    return render_template("index.html")

@app.route("/chat")
def chat():
    if "username" in session and "room" in session:
        return render_template("chat.html", username=session["username"], room=session["room"])
    return redirect(url_for("index"))

@socketio.on("join")
def handle_join(data):
    username = data["username"]
    room = data["room"]
    join_room(room)
    emit("status", {"msg": f"🔔 {username} odaya katıldı"}, room=room)

@socketio.on("leave")
def handle_leave(data):
    username = data["username"]
    room = data["room"]
    leave_room(room)
    emit("status", {"msg": f"👋 {username} odadan ayrıldı"}, room=room)

@socketio.on("text")
def handle_text(data):
    global messages
    msg_data = {"username": session["username"], "msg": data["msg"], "timestamp": time.time()}
    messages.append(msg_data)
    emit("message", {"username": msg_data["username"], "msg": msg_data["msg"]}, room=session["room"])

@socketio.on("typing")
def handle_typing(data):
    emit("typing", {"username": session["username"]}, room=session["room"], include_self=False)

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
