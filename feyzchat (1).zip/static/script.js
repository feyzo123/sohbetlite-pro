var socket = io();
var room = "{{ room }}";
var username = "{{ username }}";

socket.emit("join", {username: username, room: room});

socket.on("message", function(data){
    var chat = document.getElementById("chat");
    chat.innerHTML += "<p><b>" + data.username + ":</b> " + data.msg + "</p>";
});

function sendMessage(){
    var msg = document.getElementById("message").value;
    socket.emit("text", {msg: msg});
    document.getElementById("message").value = "";
}
