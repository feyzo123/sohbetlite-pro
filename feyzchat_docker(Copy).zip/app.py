from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory, abort
from flask_socketio import SocketIO, join_room, leave_room, emit
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, timedelta
import sqlite3, os, uuid, pathlib

DB_FILE = "feyzchat.db"
UPLOAD_DIR = "uploads"
ALLOWED_EXT = {"jpg","jpeg","png","gif","webp"}
MAX_DAYS = 5

app = Flask(__name__, static_folder="static")
app.config["SECRET_KEY"] = "feyzchat_secret"
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25 MB
socketio = SocketIO(app, async_mode="eventlet")

def db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute(
            "CREATE TABLE IF NOT EXISTS messages ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "room TEXT NOT NULL,"
            "username TEXT NOT NULL,"
            "type TEXT NOT NULL,"
            "content TEXT NOT NULL,"
            "ts DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
            "deleted INTEGER NOT NULL DEFAULT 0"
            ")"
        )
init_db()

def cleanup_old():
    cutoff = datetime.utcnow() - timedelta(days=MAX_DAYS)
    with db() as c:
        rows = c.execute("SELECT content FROM messages WHERE type='image' AND ts < ?", (cutoff.strftime("%Y-%m-%d %H:%M:%S"),)).fetchall()
        for r in rows:
            f = os.path.join(UPLOAD_DIR, r[0])
            try:
                if os.path.isfile(f):
                    os.remove(f)
            except Exception:
                pass
        c.execute("DELETE FROM messages WHERE ts < ?", (cutoff.strftime("%Y-%m-%d %H:%M:%S"),))

scheduler = BackgroundScheduler(daemon=True)
scheduler.add_job(cleanup_old, "interval", hours=24)
scheduler.start()

@app.route("/", methods=["GET","POST"])
def index():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        room = request.form.get("room","").strip()
        if not username or not room:
            return render_template("index.html", error="Kullanıcı adı ve oda gerekli.")
        session["username"] = username
        session["room"] = room
        return redirect(url_for("chat"))
    return render_template("index.html")

@app.route("/chat")
def chat():
    if "username" not in session or "room" not in session:
        return redirect(url_for("index"))
    return render_template("chat.html", username=session["username"], room=session["room"])

@app.get("/history")
def history():
    room = request.args.get("room","")
    if not room:
        return jsonify([])
    with db() as c:
        rows = c.execute("SELECT id, username, type, content, ts, deleted FROM messages WHERE room=? ORDER BY id DESC LIMIT 50", (room,)).fetchall()
    rows = list(reversed([dict(r) for r in rows]))
    return jsonify(rows)

@app.post("/upload")
def upload():
    if "username" not in session or "room" not in session:
        abort(401)
    f = request.files.get("file")
    if not f or f.filename == "":
        abort(400)
    ext = f.filename.rsplit(".",1)[-1].lower()
    if ext not in ALLOWED_EXT:
        return "Sadece resim dosyaları yüklenebilir.", 400
    filename = f"{uuid.uuid4().hex}.{ext}"
    pathlib.Path(UPLOAD_DIR).mkdir(exist_ok=True)
    path = os.path.join(UPLOAD_DIR, filename)
    f.save(path)
    with db() as c:
        c.execute("INSERT INTO messages (room, username, type, content) VALUES (?,?,?,?)",
                  (session["room"], session["username"], "image", filename))
        msg_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    from flask import url_for
    socketio.emit("message", {
        "id": msg_id,
        "username": session["username"],
        "type": "image",
        "content": url_for("uploaded_file", filename=filename),
        "ts": datetime.utcnow().isoformat(timespec="seconds"),
        "deleted": 0
    }, room=session["room"])
    return jsonify(ok=True)

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=False)

@socketio.on("join")
def on_join(data):
    username = data.get("username")
    room = data.get("room")
    join_room(room)
    emit("status", {"msg": f"🔔 {username} odaya katıldı"}, room=room)

@socketio.on("leave")
def on_leave(data):
    username = data.get("username")
    room = data.get("room")
    leave_room(room)
    emit("status", {"msg": f"👋 {username} odadan ayrıldı"}, room=room)

@socketio.on("typing")
def on_typing(data):
    emit("typing", {"username": session.get("username","")}, room=session.get("room",""), include_self=False)

@socketio.on("text")
def on_text(data):
    msg = (data.get("msg") or "").strip()
    if not msg:
        return
    with db() as c:
        c.execute("INSERT INTO messages (room, username, type, content) VALUES (?,?,?,?)",
                  (session["room"], session["username"], "text", msg))
        msg_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    emit("message", {
        "id": msg_id,
        "username": session["username"],
        "type": "text",
        "content": msg,
        "ts": datetime.utcnow().isoformat(timespec="seconds"),
        "deleted": 0
    }, room=session["room"])

@socketio.on("delete_message")
def on_delete(data):
    try:
        mid = int(data.get("id", 0))
    except Exception:
        return
    with db() as c:
        c.execute("UPDATE messages SET deleted=1, content='Bu mesaj silindi' WHERE id=? AND username=?", (mid, session["username"]))
    emit("deleted", {"id": mid}, room=session["room"])

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    socketio.run(app, host="0.0.0.0", port=port)
