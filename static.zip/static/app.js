// Modern oda sohbeti + yazıyor… + emoji + dosya yükleme + silme
const socket = io();
const msgBox = document.getElementById('messages');
const typingBar = document.getElementById('typing');
const msgInput = document.getElementById('msg');
const sendBtn = document.getElementById('sendBtn');
const filePick = document.getElementById('filePick');
const emojiBtn = document.getElementById('emojiBtn');

const room = window.FZC?.room || '';
const user = window.FZC?.user || 'Anonim';
const pass = window.FZC?.pass || '';

let typingTimeout = null;
let picker;

// Odaya bağlan (şifre doğrulama server tarafında)
socket.emit('create_or_join', { room, password: pass, user });

// Online listesi
socket.on('presence', (p) => {
  const el = document.getElementById('online');
  el.textContent = 'Çevrimiçi: ' + (p.online || []).join(', ');
});

// Sistem mesajları
socket.on('system', (d) => {
  if (!d.ok) {
    alert(d.msg || 'Hata');
    return;
  }
  addSystem(d.msg);
});

// Normal mesajlar
socket.on('message', (m) => {
  addMessage(m);
});

// Dosya mesajı
socket.on('file_message', (f) => {
  addFileMessage(f);
});

// Mesaj silindi
socket.on('message_deleted', (info) => {
  const el = document.querySelector(`.bubble[data-id="${info.id}"]`);
  if (el) {
    el.classList.add('deleted');
    el.innerHTML = 'Bu mesaj silindi';
  }
});

// Yazıyor…
msgInput?.addEventListener('input', () => {
  socket.emit('typing', { room, user, typing: true });
  if (typingTimeout) clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    socket.emit('typing', { room, user, typing: false });
  }, 1200);
});

socket.on('typing', (d) => {
  if (d.room !== room) return;
  typingBar.textContent = d.typing ? `${d.user} yazıyor…` : '';
});

// Gönder
sendBtn?.addEventListener('click', sendMessage);
msgInput?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendMessage();
});

// Dosya seç
filePick?.addEventListener('change', async (e) => {
  if (!e.target.files || !e.target.files[0]) return;
  const file = e.target.files[0];
  if (file.size > 25 * 1024 * 1024) {
    alert('Maksimum 25 MB');
    e.target.value = '';
    return;
  }
  const fd = new FormData();
  fd.append('room', room);
  fd.append('user', user);
  fd.append('file', file);
  await fetch('/upload', { method: 'POST', body: fd }).catch(()=>{});
  e.target.value = '';
});

// Emoji
if (emojiBtn && window.EmojiButton) {
  picker = new EmojiButton();
  emojiBtn.addEventListener('click', () => {
    picker.togglePicker(emojiBtn);
  });
  picker.on('emoji', emoji => {
    msgInput.value += emoji;
    msgInput.focus();
  });
}

// Uzun basınca sil menüsü (mobil/masaüstü)
msgBox.addEventListener('contextmenu', (e) => e.preventDefault());
msgBox.addEventListener('mousedown', handlePressStart);
msgBox.addEventListener('touchstart', handlePressStart);
msgBox.addEventListener('mouseup', handlePressEnd);
msgBox.addEventListener('mouseleave', handlePressEnd);
msgBox.addEventListener('touchend', handlePressEnd);
let pressTimer = null, pressTarget = null;

function handlePressStart(e){
  const target = e.target.closest('.bubble.me, .bubble');
  if (!target) return;
  pressTarget = target;
  pressTimer = setTimeout(() => {
    showDelete(target);
  }, 600);
}
function handlePressEnd(){
  clearTimeout(pressTimer);
  pressTarget = null;
}
function showDelete(el){
  if (el.classList.contains('deleted')) return;
  const id = el.dataset.id;
  if (!id) return;
  if (confirm('Mesajı sil?')) {
    socket.emit('delete_message', { room, id });
  }
}

function sendMessage(){
  const t = msgInput.value.trim();
  if (!t) return;
  socket.emit('message', { room, user, text: t });
  msgInput.value = '';
}

function addSystem(text){
  const div = document.createElement('div');
  div.className = 'bubble';
  div.style.opacity = .8;
  div.textContent = text;
  msgBox.appendChild(div);
  msgBox.scrollTop = msgBox.scrollHeight;
}

function addMessage(m){
  const div = document.createElement('div');
  div.className = 'bubble' + (m.user === user ? ' me' : '');
  div.dataset.id = m.id || '';
  div.innerHTML = sanitize(m.deleted ? 'Bu mesaj silindi' : `<b>${esc(m.user)}:</b> ${linkify(esc(m.text||''))}`) +
                  `<div class="msg-meta">${timeStr(m.time)}</div>`;
  msgBox.appendChild(div);
  msgBox.scrollTop = msgBox.scrollHeight;
}

function addFileMessage(f){
  const isImg = ['png','jpg','jpeg','gif','webp'].includes((f.ext||'').toLowerCase());
  const div = document.createElement('div');
  div.className = 'bubble' + (f.user === user ? ' me' : '');
  div.dataset.id = f.id || '';
  let inner = `<b>${esc(f.user)}:</b>`;
  if (isImg){
    inner += `<div class="msg-file"><img src="${f.url}" alt="img"><a class="dl" href="${f.url}" download>İndir</a></div>`;
  } else {
    inner += `<div class="msg-file"><span>📄 ${esc(f.filename)}</span> <a class="dl" href="${f.url}" download>İndir</a></div>`;
  }
  inner += `<div class="msg-meta">${timeStr(f.time)}</div>`;
  div.innerHTML = inner;
  msgBox.appendChild(div);
  msgBox.scrollTop = msgBox.scrollHeight;
}

// helpers
function esc(s){ return (s||'').replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function linkify(s){ return s.replace(/(https?:\/\/\S+)/g, '<a href="$1" target="_blank">$1</a>'); }
function timeStr(iso){ try{ const d = new Date(iso); return d.toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'});}catch{ return ''; } }